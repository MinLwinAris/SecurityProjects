Project Title: Android TOTP Authenticator Application developed by Min Lwin TP028322

Description:
This Android application generates Time-Based One-Time Passwords (TOTP)
and supports multi-account management, biometric app lock, and backup
export/import.

Requirements:
- Android Studio
- Minimum SDK: Android 10+

How to Run:
1. Open the project in Android Studio
2. Sync Gradle
3. Run on emulator or physical device
4. Install necessary libraries.

