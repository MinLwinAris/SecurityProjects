package com.minlwin.totpauthenticator

import android.os.Bundle                     // Android OS bundle for activity state
import androidx.activity.compose.setContent   // Compose UI content setting
import androidx.activity.enableEdgeToEdge     // Edge-to-edge display support

// Jetpack Compose UI imports
import androidx.compose.foundation.layout.*           // Compose layout components
import androidx.compose.material3.*                   // Material Design 3 components
import androidx.compose.runtime.*                     // Compose reactive state management
import androidx.compose.ui.Alignment                  // UI alignment utilities
import androidx.compose.ui.Modifier                   // UI modifier chaining
import androidx.compose.ui.tooling.preview.Preview    // UI preview tools
import androidx.compose.ui.unit.dp                    // Density-independent pixels
import com.minlwin.totpauthenticator.ui.theme.TOTPAuthenticatorTheme  // Custom app theme

// Cryptography and TOTP generation
import java.nio.ByteBuffer                             // Byte buffer utilities
import javax.crypto.Mac                                // Message Authentication Code (HMAC)
import javax.crypto.spec.SecretKeySpec                 // Secret key specification
import kotlin.math.floor                               // Math utilities

// Biometric authentication
import androidx.biometric.BiometricManager             // Biometric hardware check
import androidx.biometric.BiometricPrompt              // Biometric authentication UI
import androidx.core.content.ContextCompat             // Context utilities
import androidx.fragment.app.FragmentActivity          // Activity for biometric

// Coroutines for asynchronous operations
import kotlinx.coroutines.delay                       // Coroutine delay/suspension

// Lifecycle management for biometric security
import androidx.lifecycle.Lifecycle                     // App lifecycle states
import androidx.lifecycle.LifecycleEventObserver        // Lifecycle event observer
import androidx.lifecycle.compose.LocalLifecycleOwner   // Lifecycle owner in Compose

// Context access in Compose
import androidx.compose.ui.platform.LocalContext        // Access to Android context

// List UI components
import androidx.compose.foundation.lazy.LazyColumn      // Efficient scrolling list
import androidx.compose.foundation.lazy.items           // List item rendering

// Swipe-to-dismiss functionality
import androidx.compose.material.DismissDirection       // Swipe direction
import androidx.compose.material.DismissValue           // Dismiss state values
import androidx.compose.material.SwipeToDismiss         // Swipe dismissal component
import androidx.compose.material.rememberDismissState   // Dismiss state management
import androidx.compose.material.ExperimentalMaterialApi // Experimental APIs

// UI styling and colors
import androidx.compose.ui.graphics.Color               // Color definitions

// Navigation bar handling
import androidx.compose.foundation.layout.navigationBarsPadding  // Safe area padding

// URI handling for file imports
import android.net.Uri                                  // Android URI handling

// Background and shape styling
import androidx.compose.foundation.background           // Background color/styling
import androidx.compose.foundation.shape.CircleShape    // Circle shape utility

// Image manipulation
import androidx.compose.ui.draw.clip                    // View clipping

// Text styling
import androidx.compose.ui.text.style.TextAlign         // Text alignment

// Material icons
import androidx.compose.material.icons.Icons            // Material icon resources
import androidx.compose.material.icons.outlined.Lock    // Lock icon
import androidx.compose.material.icons.outlined.AccountCircle // Account icon

// Vector graphics
import androidx.compose.ui.graphics.vector.ImageVector   // Vector image support

// Resource annotations and loading
import androidx.annotation.DrawableRes                    // Drawable resource annotation
import androidx.compose.ui.res.painterResource           // Load drawable resources

// Image display
import androidx.compose.foundation.Image                 // Image composable
import androidx.compose.ui.res.painterResource           // Resource loading (duplicate - already imported)
import androidx.compose.ui.layout.ContentScale           // Image scaling modes



class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val incomingUri = intent?.data
        enableEdgeToEdge()
        setContent {
            TOTPAuthenticatorTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    AppLockGate(modifier = Modifier.padding(innerPadding)) {
                        TotpScreen(
                            modifier = Modifier.fillMaxSize(),
                            importUri = incomingUri
                        )
                   }
                }
            }
        }
    }
}

@Composable
fun AppLockGate(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val activity = (androidx.compose.ui.platform.LocalContext.current as FragmentActivity)
    var unlocked by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                // App went to background → lock again
                unlocked = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val canAuth = remember {
        val manager = BiometricManager.from(activity)
        manager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
    }

    fun promptBiometric() {
        errorMsg = null

        val executor = ContextCompat.getMainExecutor(activity)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                unlocked = true
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                errorMsg = errString.toString()
            }

            override fun onAuthenticationFailed() {
                errorMsg = "Authentication failed. Try again."
            }
        }

        val prompt = BiometricPrompt(activity, executor, callback)

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock TOTP Authenticator")
            .setSubtitle("Use fingerprint/face or phone PIN")
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        prompt.authenticate(promptInfo)
    }

    LaunchedEffect(Unit) {
        if (!unlocked && canAuth == BiometricManager.BIOMETRIC_SUCCESS) {
            promptBiometric()
        } else if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            // If biometrics not available, allow entry (we can make it strict later)
            unlocked = true
        }
    }

    if (unlocked) {
        content()
    } else {
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header at top (same style as your main screen)
            Text(
                text = "TOTP Authenticator",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(top = 32.dp)
            )

            // Push the lock content to the middle
            Spacer(modifier = Modifier.weight(1f))

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_minlwin_logo), //personal logo
                    contentDescription = "App logo",
                    modifier = Modifier.size(220.dp), // adjust: 180.dp / 220.dp / 260.dp
                    contentScale = ContentScale.Fit
                )

                Text("App Locked", style = MaterialTheme.typography.titleLarge)
                Text("Authentication to view your TOTP codes.")

                Button(onClick = { promptBiometric() }) {
                    Text("Unlock")
                }

                if (errorMsg != null) {
                    Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
                }
            }

            // Balance the middle spacing
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}
@OptIn(ExperimentalMaterialApi::class)
@Composable                             // very important TOTP screen
fun TotpScreen(modifier: Modifier = Modifier, importUri: Uri? = null) {
    val context = LocalContext.current
    val storage = remember { SecureStorage(context) }

    val accounts = remember { mutableStateListOf<TotpAccount>() }
    var selected by remember { mutableStateOf<TotpAccount?>(null) }

    var showScanner by remember { mutableStateOf(false) }

    // Simple user feedback (shows messages like "Exported..." / "Imported...")
    var statusMsg by remember { mutableStateOf<String?>(null) }

    var otp by remember { mutableStateOf("------") }
    var secondsLeft by remember { mutableIntStateOf(30) }

    //  LOAD accounts first, THEN auto-import if launched via "Open with"
    LaunchedEffect(Unit) {
        // 1) Load existing accounts
        val saved = storage.loadAccounts()
        accounts.clear()
        accounts.addAll(saved)
        selected = saved.firstOrNull()

        // 2) Auto-import backup if app opened with a JSON file
        if (importUri != null) {
            try {
                val jsonText = context.contentResolver.openInputStream(importUri)?.use { input ->
                    input.readBytes().toString(Charsets.UTF_8)
                } ?: throw IllegalStateException("Cannot read selected file")

                val (merged, summary) = BackupManager.importMerge(
                    jsonText = jsonText,
                    existingAccounts = accounts.toList()
                )

                storage.saveAccounts(merged)
                accounts.clear()
                accounts.addAll(merged)

                if (selected == null) selected = merged.firstOrNull()

                statusMsg = "Imported ${summary.added}, skipped ${summary.skipped}."
            } catch (e: Exception) {
                statusMsg = "Import failed: ${e.message ?: "unknown error"}"
            }
        }
    }

    // To always generate OTP for currently selected account
    LaunchedEffect(selected?.secret) {
        while (true) {
            val nowSec = System.currentTimeMillis() / 1000L
            secondsLeft = (30 - (nowSec % 30)).toInt()

            val secret = selected?.secret.orEmpty()
            otp = try {
                if (secret.isBlank()) "------"
                else Totp.generateTotp(secret, nowSec)
            } catch (e: Exception) {
                "ERROR"
            }

            delay(250)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "TOTP Authenticator", //Header of the App
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(top = 32.dp)
        )


        Button(onClick = { showScanner = true }) {
            Text("Scan QR (Add Account)")
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp), //export & import button
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { //EXPORT BUTTON
                try {
                    val json = BackupManager.exportToJson(accounts.toList())
                    ExportToDownloads.exportJson(
                        context = context,
                        fileName = "totp_backup.json",
                        jsonText = json
                    )
                    statusMsg = "Backup saved to Downloads/totp_backup.json"
                } catch (e: Exception) {
                    statusMsg = "Export failed: ${e.message}"
                }
            }) {
                Text("Export Backup")
            }

            OutlinedButton(onClick = { //IMPORT BUTTON
                try {
                    val uri = ImportFromDownloads.findLatestBackupUri(
                        context,
                        "totp_backup.json"
                    ) ?: throw IllegalStateException(
                        "No totp_backup.json found in Downloads"
                    )

                    val jsonText = ImportFromDownloads.readText(context, uri)

                    val (merged, summary) = BackupManager.importMerge(
                        jsonText = jsonText,
                        existingAccounts = accounts.toList()
                    )

                    storage.saveAccounts(merged)
                    accounts.clear()
                    accounts.addAll(merged)

                    if (selected == null || merged.none { it == selected }) {
                        selected = merged.firstOrNull()
                    }

                    statusMsg = "Imported ${summary.added}, skipped ${summary.skipped}."
                } catch (e: Exception) {
                    statusMsg = "Import failed: ${e.message ?: "unknown error"}"
                }
            }) {
                Text("Import Backup")
            }

        }
        if (accounts.isEmpty()) {
            Text(
                "To restore after reinstall: open totp_backup.json from Downloads and choose this app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (statusMsg != null) {
            Text(
                text = statusMsg!!,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // Current code card
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT: keep everything exactly as before (including seconds)
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Selected account")
                    Text(
                        text = selected?.let { "${it.issuer} • ${it.label}" } ?: "None",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("Current code")
                    Text(otp, style = MaterialTheme.typography.displayMedium)
                    Text("Refresh in $secondsLeft s")
                }

                Spacer(modifier = Modifier.width(12.dp))

                // RIGHT: simple issuer badge (Step 2 we replace with Google/X icons)
                val logoRes = issuerLogoRes(selected?.issuer)

                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest),
                    contentAlignment = Alignment.Center
                ) {
                    if (logoRes != null) {
                        Icon(
                            painter = painterResource(id = logoRes),
                            contentDescription = selected?.issuer,
                            tint = Color.Unspecified, // IMPORTANT: keep real logo colors
                            modifier = Modifier.size(42.dp) //Logo icon size
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Lock,
                            contentDescription = "Account",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }


        // Accounts list
        if (accounts.isEmpty()) {
            Spacer(modifier = Modifier.weight(1f))
            Text("No accounts yet. Tap “Scan QR” to add one.")
        } else {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Accounts", style = MaterialTheme.typography.titleMedium)

            LazyColumn(  //Multiple Account List Rendering
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = accounts,
                    key = { "${it.issuer}|${it.label}|${it.secret}" }
                ) { acct ->

                    val dismissState = rememberDismissState(  // account deleting and swip dismiss
                        confirmStateChange = { value ->
                        if (
                                value == DismissValue.DismissedToStart ||
                                value == DismissValue.DismissedToEnd
                            ) {
                                storage.deleteAccount(acct)

                                val saved = storage.loadAccounts()
                                accounts.clear()
                                accounts.addAll(saved)

                                if (selected == acct) {
                                    selected = saved.firstOrNull()
                                }
                                true
                            } else {
                                false
                            }
                        }
                    )

                    SwipeToDismiss(
                        state = dismissState,
                        directions = setOf(
                            DismissDirection.StartToEnd,
                            DismissDirection.EndToStart
                        ),
                        background = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(12.dp),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = "Delete",
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        },
                        dismissContent = {
                            val isSelected = acct == selected

                            Card(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(acct.issuer, style = MaterialTheme.typography.titleMedium)
                                        Text(acct.label, style = MaterialTheme.typography.bodySmall)
                                    }
                                    OutlinedButton(onClick = { selected = acct }) {
                                        Text(if (isSelected) "Selected" else "Select")
                                    }
                                }
                            }
                        }
                    )
                }
            }
        }


        Text(
            text = "Developed by Min Lwin", //footer
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier
                .navigationBarsPadding()
                .padding(top = 8.dp)
        )
    }

    // QR scanner
    if (showScanner) {
        QrScanner(
            onCancel = { showScanner = false },
            onResult = { rawValue ->
                // IMPORTANT: must return TotpAccount? (issuer/label/secret)
                val acct = OtpAuthParser.parse(rawValue)

                if (acct != null) {
                    storage.addAccount(acct)

                    val saved = storage.loadAccounts()
                    accounts.clear()
                    accounts.addAll(saved)

                    selected = saved.lastOrNull()
                }

                showScanner = false
            }
        )
    }
}

/**
 * Decide which icon to show for an issuer name
 */

@DrawableRes
private fun issuerLogoRes(issuer: String?): Int? {       //Call the logo icons from input
    val s = issuer?.trim()?.lowercase().orEmpty()

    return when {
        // Google
        "google" in s || "gmail" in s -> R.drawable.ic_google

        // GitHub
        "github" in s -> R.drawable.ic_github

        // Microsoft
        "microsoft" in s || "outlook" in s || "azure" in s -> R.drawable.ic_microsoft

        // Facebook / Meta
        "facebook" in s || "meta" in s -> R.drawable.ic_facebook

        // Amazon
        "amazon" in s || "aws" in s -> R.drawable.ic_amazon

        // Apple
        "apple" in s || "icloud" in s -> R.drawable.ic_apple

        // Discord
        "discord" in s -> R.drawable.ic_discord

        else -> null
    }
}
@Preview(showBackground = true)
@Composable
fun TotpPreview() {
    TOTPAuthenticatorTheme {
        TotpScreen()
    }
}

/**
 * Minimal RFC 6238 TOTP (HMAC-SHA1, 30s step, 6 digits)
 */
object Totp {  //main TOTP function
    fun generateTotp(
        base32Secret: String,
        timeSeconds: Long,
        timeStepSeconds: Long = 30,
        digits: Int = 6
    ): String {
        val key = Base32.decode(base32Secret.uppercase())
        val counter = floor(timeSeconds.toDouble() / timeStepSeconds.toDouble()).toLong()

        // 8-byte big-endian counter
        val msg = ByteBuffer.allocate(8).putLong(counter).array()

        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(key, "HmacSHA1"))
        val hash = mac.doFinal(msg)

        // Dynamic truncation (RFC 4226)
        val offset = hash[hash.size - 1].toInt() and 0x0F
        val binary =
            ((hash[offset].toInt() and 0x7F) shl 24) or
                    ((hash[offset + 1].toInt() and 0xFF) shl 16) or
                    ((hash[offset + 2].toInt() and 0xFF) shl 8) or
                    (hash[offset + 3].toInt() and 0xFF)

        val otpInt = binary % pow10(digits)
        return otpInt.toString().padStart(digits, '0')
    }

    private fun pow10(n: Int): Int {
        var r = 1
        repeat(n) { r *= 10 }
        return r
    }
}

/**
 * Base32 decoder (RFC 4648 alphabet). Padding optional.
 */
object Base32 {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    fun decode(inputRaw: String): ByteArray {
        val input = inputRaw.replace("=", "").replace(" ", "").uppercase()
        require(input.isNotEmpty()) { "Secret is empty" }

        var buffer = 0
        var bitsLeft = 0
        val out = ArrayList<Byte>()

        for (c in input) {
            val v = ALPHABET.indexOf(c)
            require(v != -1) { "Invalid Base32 character: $c" }

            buffer = (buffer shl 5) or v
            bitsLeft += 5

            if (bitsLeft >= 8) {
                bitsLeft -= 8
                val b = (buffer shr bitsLeft) and 0xFF
                out.add(b.toByte())
            }
        }
        return out.toByteArray()
    }
}
