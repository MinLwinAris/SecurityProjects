package com.minlwin.totpauthenticator

import android.content.Context
import android.net.Uri
import android.provider.MediaStore

object ImportFromDownloads {

    fun findLatestBackupUri(context: Context, fileName: String): Uri? {
        val resolver = context.contentResolver
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI

        val projection = arrayOf(
            MediaStore.Downloads._ID,
            MediaStore.Downloads.DISPLAY_NAME
        )

        val selection = "${MediaStore.Downloads.DISPLAY_NAME}=?"
        val selectionArgs = arrayOf(fileName)

        // newest first
        val sortOrder = "${MediaStore.Downloads.DATE_ADDED} DESC"

        resolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            sortOrder
        )?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
            if (cursor.moveToFirst()) {
                val id = cursor.getLong(idCol)
                return Uri.withAppendedPath(collection, id.toString())
            }
        }
        return null
    }

    fun readText(context: Context, uri: Uri): String {
        return context.contentResolver.openInputStream(uri)?.use { input ->
            input.readBytes().toString(Charsets.UTF_8)
        } ?: throw IllegalStateException("Cannot read backup file")
    }
}
