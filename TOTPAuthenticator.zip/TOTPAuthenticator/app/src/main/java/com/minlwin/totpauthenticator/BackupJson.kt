package com.minlwin.totpauthenticator

import kotlinx.serialization.json.Json

object BackupJson {
    val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
        encodeDefaults = true
    }
}
