package com.minlwin.totpauthenticator

import android.annotation.SuppressLint
import kotlinx.serialization.Serializable

@Serializable
data class TotpAccount(
    val issuer: String,
    val label: String,
    val secret: String
)
