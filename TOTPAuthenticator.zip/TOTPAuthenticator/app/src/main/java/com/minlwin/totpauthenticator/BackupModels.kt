package com.minlwin.totpauthenticator

import kotlinx.serialization.Serializable

@Serializable
data class BackupFileV1(
    val version: Int = 1,
    val exportedAt: String,
    val app: String = "TOTPAuthenticator",
    val accounts: List<BackupAccountV1>
)

@Serializable
data class BackupAccountV1(
    val issuer: String,
    val label: String,
    val secret: String,
    val digits: Int = 6,
    val period: Int = 30,
    val algorithm: String = "SHA1"
)
