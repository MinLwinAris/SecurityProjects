package com.minlwin.totpauthenticator

import androidx.core.net.toUri
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

object OtpAuthParser {

    fun parse(raw: String): TotpAccount? {
        if (!raw.startsWith("otpauth://", ignoreCase = true)) return null

        return try {
            val uri = raw.toUri()

            val secret = uri.getQueryParameter("secret") ?: return null
            val issuerParam = uri.getQueryParameter("issuer")

            // Label is path after /totp/
            val path = uri.path?.removePrefix("/") ?: "Account"
            val decodedLabel = URLDecoder.decode(path, StandardCharsets.UTF_8.name())

            val issuerFromLabel = decodedLabel.substringBefore(":", missingDelimiterValue = decodedLabel)
            val labelOnly = decodedLabel.substringAfter(":", missingDelimiterValue = decodedLabel)

            val issuer = issuerParam ?: issuerFromLabel
            val label = labelOnly.ifBlank { "Account" }

            TotpAccount(
                issuer = issuer,
                label = label,
                secret = secret
            )
        } catch (_: Exception) {
            null
        }
    }
}
