package com.minlwin.totpauthenticator.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF0ECEE7)
val PurpleGrey80 = Color(0xFF21D0DE)
val Pink80 = Color(0xFF1CD5EC)

val Purple40 = Color(0xFF007AFF)      // iOS blue
val PurpleGrey40 = Color(0xFF0A84FF)  // lighter blue
val Pink40 = Color(0xFF007AFF)

//val CardTint = Color(0xFFF3F4F6)   // light elegant card
//val CardTint2 = Color(0xFFEDEFF2)  // slightly deeper
val CardTint = Color(0xFFF7F8FA)
val CardTint2 = Color(0xFFF1F3F6) // Cards background




