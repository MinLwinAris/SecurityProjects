package com.minlwin.totpauthenticator

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ImportSummary(
    val added: Int,
    val skipped: Int
)

object BackupManager {

    fun exportToJson(currentAccounts: List<TotpAccount>): String {
        val timestamp = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(Date())

        val backup = BackupFileV1(
            version = 1,
            exportedAt = timestamp,
            accounts = currentAccounts.map {
                BackupAccountV1(
                    issuer = it.issuer,
                    label = it.label,
                    secret = it.secret
                )
            }
        )

        return BackupJson.json.encodeToString(BackupFileV1.serializer(), backup)
    }

    fun importMerge(
        jsonText: String,
        existingAccounts: List<TotpAccount>
    ): Pair<List<TotpAccount>, ImportSummary> {
        val backup = BackupJson.json.decodeFromString(BackupFileV1.serializer(), jsonText)

        val existingKeySet = existingAccounts
            .map { keyOf(it.issuer, it.label) }
            .toMutableSet()

        val merged = existingAccounts.toMutableList()

        var added = 0
        var skipped = 0

        for (acc in backup.accounts) {
            val k = keyOf(acc.issuer, acc.label)
            if (existingKeySet.contains(k)) {
                skipped++
            } else {
                merged.add(
                    TotpAccount(
                        issuer = acc.issuer,
                        label = acc.label,
                        secret = acc.secret
                    )
                )
                existingKeySet.add(k)
                added++
            }
        }

        return merged to ImportSummary(added = added, skipped = skipped)
    }

    private fun keyOf(issuer: String, label: String): String =
        issuer.trim().lowercase() + "||" + label.trim().lowercase()
}
