package com.minlwin.totpauthenticator

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

class SecureStorage(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_totp_storage",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val json = Json { ignoreUnknownKeys = true }

    private companion object {
        private const val KEY_ACCOUNTS_JSON = "totp_accounts_json"
        private const val KEY_LEGACY_SECRET = "totp_secret"
    }

    /* =========================
       MULTI-ACCOUNT API
       ========================= */

    fun loadAccounts(): List<TotpAccount> {
        val text = prefs.getString(KEY_ACCOUNTS_JSON, null)
        if (!text.isNullOrBlank()) {
            return runCatching {
                json.decodeFromString(
                    ListSerializer(TotpAccount.serializer()),
                    text
                )
            }.getOrElse { emptyList() }
        }

        // Legacy single-secret migration
        val legacy = prefs.getString(KEY_LEGACY_SECRET, null)
        if (!legacy.isNullOrBlank()) {
            val migrated = listOf(
                TotpAccount(
                    issuer = "Imported",
                    label = "Account",
                    secret = legacy
                )
            )
            saveAccounts(migrated)
            prefs.edit().remove(KEY_LEGACY_SECRET).apply()
            return migrated
        }

        return emptyList()
    }

    fun addAccount(account: TotpAccount) {
        val current = loadAccounts().toMutableList()

        // Merge rule: duplicate = same issuer + label (ignore secret)
        val exists = current.any {
            it.issuer.trim().equals(account.issuer.trim(), ignoreCase = true) &&
                    it.label.trim().equals(account.label.trim(), ignoreCase = true)
        }

        if (!exists) {
            current.add(account)
            saveAccounts(current)
        }
    }


    fun saveAccounts(accounts: List<TotpAccount>) {
        val encoded = json.encodeToString(
            ListSerializer(TotpAccount.serializer()),
            accounts
        )
        prefs.edit().putString(KEY_ACCOUNTS_JSON, encoded).apply()
    }

    fun deleteAccount(account: TotpAccount) {
        val current = loadAccounts().toMutableList()
        current.removeAll {
            it.issuer == account.issuer &&
                    it.label == account.label &&
                    it.secret == account.secret
        }
        saveAccounts(current)
    }

    /* =========================
       LEGACY API (TEMP)
       Allows MainActivity to compile
       ========================= */

    fun saveSecret(secret: String) {
        saveAccounts(
            listOf(
                TotpAccount(
                    issuer = "Imported",
                    label = "Account",
                    secret = secret
                )
            )
        )
    }

    fun loadSecret(): String? {
        return loadAccounts().firstOrNull()?.secret
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
